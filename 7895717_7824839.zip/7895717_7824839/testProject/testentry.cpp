//
//  testEntry.cpp
//  2372test
//
//  Created by Huairuo Yang on 2018-12-09.
//  Copyright © 2018 Huairuo Yang(7895717). All rights reserved.
//

#include "testEntry.hpp"
